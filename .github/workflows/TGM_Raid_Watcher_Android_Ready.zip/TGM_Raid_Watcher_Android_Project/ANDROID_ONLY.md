# Android-only installation path

This project includes a GitHub Actions workflow that builds the APK for you.

1. Create a GitHub repository from your Android browser.
2. Upload all files from this project to the repository.
3. Open the repository's Actions tab.
4. Select "Build APK" and run it.
5. When it finishes, open the workflow run and download the artifact named `TGM-Raid-Watcher-debug`.
6. Extract the downloaded artifact and install `app-debug.apk` on your Android phone.
7. Android may ask you to allow installation from your browser/file manager.
8. Open TGM Raid Watcher, allow "Display over other apps", then approve screen capture.

The app is a prototype. It OCRs the screen and currently needs real raid screenshots for the accuracy-tuning pass.
